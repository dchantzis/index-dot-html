<?php
$pathID = 31;
getTagsFromPath($pathID);

function getTagsFromPath($pathID)
{
	require_once('indexdbase.class.php'); //include class with connection to the database, and constructor
	$dbobj = new IndexDBase(); //call the constructor
	$tagsArr = array();
	
	$selectALLtagsQuery = 'SELECT tags.id, tags.name FROM tags'; //get all the tags
	$selectAlltagsResult = @mysql_query($selectALLtagsQuery);
	$selectAlltagsNum = @mysql_num_rows($selectAlltagsResult);
	
	if($selectAlltagsNum != 0)
	{		
		for($j=0; $j<$selectAlltagsNum; $j++)
		{
			$tagID = @mysql_result($selectAlltagsResult,$j,'id');
			$tagName = @mysql_result($selectAlltagsResult,$j,'name');

			$tagArrCounter[$tagID] = 0; //ARRAY THAT SAVES HOW MANY TIMES EACH TAG APPEARS AT EVERY WALK
			$tagsArrName[$tagID] = $tagName; //ARRAY THAT SAVES THE NAMES OF THE TAGS
		}//for

		$selectAllWalksQuery = "SELECT walks.order_of_paths, walks.time_of_day, walks.tags FROM walks; ";
		$selectAllWalksResult = @mysql_query($selectAllWalksQuery);
		$selectAllWalksNum = @mysql_num_rows($selectAllWalksResult);

		if($selectAllWalksNum !=0 )
		{
			for($k=0; $k<$selectAllWalksNum; $k++)
			{
				$tempOrderOfPaths = @mysql_result($selectAllWalksResult,$k,'order_of_paths');
				$tempTimeOfDay = @mysql_result($selectAllWalksResult,$k,'time_of_day');
				$tempTags = @mysql_result($selectAllWalksResult,$k,'tags');
				
				//Find which walks passed throught the path we want.
				$tempOrderOfPaths = explode(',',$tempOrderOfPaths);
				unset($tempOrderOfPaths[count($tempOrderOfPaths)-1]);
				for($i=0; $i<count($tempOrderOfPaths); $i++)
				{
					if($tempOrderOfPaths[$i] == $pathID)
					{
						//This walk passed through our path!
						//Now get me all the tags from that walk
						$tempTags = explode(',',$tempTags);
						unset($tempTags[count($tempTags)-1]);
						$tagArrCounter[$tagID]++;
					}//if
				}//inner for
			}//outer for
			
			
			//find the min and max values of tag occurances in the path
			reset($tagArrCounter);
			$maxValue = 0;
			while (list($key, $val) = each ($tagArrCounter))
			{
				if($tagArrCounter[$key]>$maxValue)
					{$maxValue=$tagArrCounter[$key]; $minValue=$tagsArr[$key]; $maxValueTagName = $tagsArrName[$tagArrCounter[$key]];}
				if($tagsArr[$key]<$minValue)
					{$minValue=$tagArrCounter[$key]; $minValueTagName = $tagsArrName[$tagArrCounter[$key]]; }
			}//while
			
			//difference between max and min
			$difference = $maxValue-$minValue;
			$distribution = $difference/3;
			
			//DISPLAY THE TAGS
			$tagsUL = "<ul id='path_tags'>";
			reset($tagArrCounter);
			while (list($key, $val) = each ($tagArrCounter))
			{
				$liClass='smallTag';
				if($tagArrCounter[$key]==$minValue){$liClass='smallestTag';}
				else if($tagArrCounter[$key]==$maxValue){$liClass='largestTag';}
				else if($tagArrCounter[$key]>($minValue+($distribution*2))){$liClass='largeTag';}
				else if($tagArrCounter[$key]>($minValue+$distribution)){$liClass='mediumTag';}
		
				$tagsUL.="<li class='".$liClass."'>"."<span>".$tagsArrName[$key].'</span>'.'</li>';
			}//while
			$tagsUL.="</ul>";
			echo $tagsUL;
		}//if
		else{}
		
	}else{}//no query result
	unset($dbobj);
}//returnArtistCategoriesTagCloud()
?>